// Import stylesheets
import './reset.css';
import './backgrounds.css';
import './style.css';

// STEPS

// STEP 1
// 1) associare gli elementi HTML alle variabili javascript per poter poi manipolare l'interfaccia

// >>>> STEP 2
// 1) associare dei listener ai box delle scelte del giocatore (rock, scissors, paper)
// 2) aggiungere la classe "selected-player-choice" al box che viene cliccato
// 3) assicurarsi che solo una mossa per volta possa essere selezionata (in pratica rimuovere la classe "selected-player-choice" dai box delle mosse differenti da quello cliccato)

// associare gli elementi HTML alle variabili javascript
const rockButton = document.getElementById('rock');
const scissorsButton = document.getElementById('scissors');
const paperButton = document.getElementById('paper');

const aiChoceBox = document.getElementById('ai-choice-box');
const winnerText = document.getElementById('winner-text');

const playerVictoriesCount = document.getElementById('player-victories-count');
const aiVictoriesCount = document.getElementById('ai-victories-count');
