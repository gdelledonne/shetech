// Import stylesheets
import './reset.css';
import './backgrounds.css';
import './style.css';

// STEPS

// STEP 1
// 1) associare gli elementi HTML alle variabili javascript per poter poi manipolare l'interfaccia

// STEP 2
// 1) associare dei listener ai box delle scelte del giocatore (rock, scissors, paper)
// 2) aggiungere la classe "selected-player-choice" al box che viene cliccato
// 3) assicurarsi che solo una mossa per volta possa essere selezionata (in pratica rimuovere la classe "selected-player-choice" dai box delle mosse differenti da quello cliccato)

// STEP 3
// 1) simulare la scelta dell'opzione da parte dell'AI (utilizzare il metodo Math.random per generare un valore casuale tra le tre possibili scelte)
// 2) mostrare la scelta operata dall'AI aggiungendo al box con id "ai-choice-box" la classe css relativa alla scelta fatta
// 3) memorizzare la scelta fatta in una variabile (servirà poi a determinare il vincitore)

// STEP 3
// 1) implementare la funzione "makeAIChoice" che simula la scelta dell'opzione da parte dell'AI (utilizzare il metodo Math.random per generare un valore casuale tra le tre possibili scelte) e che restituisce come output la scelta fatta
// 2) mostrare la scelta operata dall'AI aggiungendo al box con id "ai-choice-box" la classe css relativa alla scelta fatta
// 3) memorizzare la scelta fatta in una variabile (servirà poi a determinare il vincitore)

// STEP 4
// 1) creare una funzione che implementi la logica che determina il vincitore della mano date la mosse del giocatore e dell'AI utilizzando le regole del gioco (sasso vince su forbice, ecc ecc):
// - la funzione riceve in input la mossa del giocatore e la mossa dell'ai (memorizzata al passo precedente)
// - restituisce in output la string "Hai vinto" se vince il giocatore, "Hai perso" se vince l'ai o "Hai pareggiato" altrimenti
// 2) mostrare il vincitore della mano utilizzando l'elemento con id "winner-text"

// >>>> STEP 5
// 2) aggiungere alla logica di calcolo del vincitore il conteggio delle mani vinte dal player e dall'ai
// 4) aggiornare i punteggi sulla UI (mani vinte dal player vs mani vinte dall'AI)

// associare gli elementi HTML alle variabili javascript
const rockButton = document.getElementById('rock');
const scissorsButton = document.getElementById('scissors');
const paperButton = document.getElementById('paper');

const aiChoceBox = document.getElementById('ai-choice-box');
const winnerText = document.getElementById('winner-text');

const playerVictoriesCount = document.getElementById('player-victories-count');
const aiVictoriesCount = document.getElementById('ai-victories-count');

let playerVictories = 0;
let aiVictories = 0;

// date la mossa del giocatore e quella dell'ai determino il vincitore
function whoWon(userMove, aiMove) {
  // la stessa mossa porta a pareggio
  if (userMove == aiMove) {
    return 'Hai pareggiato';
  } else {
    // se il giocatore ha scelto rock, allora l'ai può aver scelto scissors oppure paper (rock è escluso per il primo if)
    if (userMove == 'rock') {
      if (aiMove == 'scissors') {
        // rock > scissors => vince il giocatore
        return 'Hai vinto';
      } else {
        // altrimenti rock < paper => vince AI
        return 'Hai perso';
      }
    }

    if (userMove == 'paper') {
      if (aiMove == 'rock') {
        return 'Hai vinto';
      } else {
        return 'Hai perso';
      }
    }

    if (userMove == 'scissors') {
      if (aiMove == 'paper') {
        return 'Hai vinto';
      } else {
        return 'Hai perso';
      }
    }
  }
}

// simulare la scelta dell'opzione da parte dell'AI
function makeAIChoice() {
  // possibili opzioni
  const moves = ['rock', 'scissors', 'paper'];

  // simulare la scelta di una opzione casuale
  const aiChoice = moves[Math.floor(Math.random() * moves.length)];

  // rimuovere tutte le possibili scelte fatte precedentemente dall'AI
  aiChoceBox.classList.remove('rock-bkg');
  aiChoceBox.classList.remove('scissors-bkg');
  aiChoceBox.classList.remove('paper-bkg');

  // mostra la scelta operata
  aiChoceBox.classList.add(aiChoice + '-bkg');

  return aiChoice;
}

// PLAYER CHOICES BOXES LISTENERS
rockButton.addEventListener('click', function () {
  // aggiungere la classe "selected-player-choice" al box che viene cliccato
  rockButton.classList.add('selected-player-choice');

  // assicurarsi che solo una mossa per volta possa essere selezionata
  scissorsButton.classList.remove('selected-player-choice');
  paperButton.classList.remove('selected-player-choice');

  // memorizza la scelta dell'AI
  const aiMove = makeAIChoice();

  // determina il vincitore
  const result = whoWon('rock', aiMove);

  // mostra il risultato della giocata
  winnerText.textContent = result;
});

scissorsButton.addEventListener('click', function () {
  scissorsButton.classList.add('selected-player-choice');
  rockButton.classList.remove('selected-player-choice');
  paperButton.classList.remove('selected-player-choice');

  const aiMove = makeAIChoice();

  const result = whoWon('scissors', aiMove);

  winnerText.textContent = result;
});

paperButton.addEventListener('click', function () {
  paperButton.classList.add('selected-player-choice');
  rockButton.classList.remove('selected-player-choice');
  scissorsButton.classList.remove('selected-player-choice');

  const aiMove = makeAIChoice();

  const result = whoWon('paper', aiMove);

  winnerText.textContent = result;
});
