// Import stylesheets
import './reset.css';
import './backgrounds.css';
import './style.css';

// STEPS

// >>>> STEP 1
// 1) associare gli elementi HTML alle variabili javascript per poter poi manipolare l'interfaccia
